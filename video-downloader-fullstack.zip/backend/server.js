import express from "express";
import cors from "cors";
import morgan from "morgan";
import { spawn } from "child_process";
import ytdlp from "yt-dlp-exec";
import ffmpegPath from "ffmpeg-static";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const ALLOW_ORIGIN = process.env.ALLOW_ORIGIN || "*";
const MAX_FILESIZE = process.env.MAX_FILESIZE || "200M"; // e.g., 200M, 100M

app.use(cors({ origin: ALLOW_ORIGIN }));
app.use(morgan("tiny"));

const isValidUrl = (s) => {
  try { new URL(s); return true; } catch { return false; }
};

// Health check
app.get("/", (_req, res) => {
  res.json({ ok: true, service: "video-downloader-backend" });
});

// Fetch basic info and available formats
app.get("/info", async (req, res) => {
  const url = req.query.url;
  if (!url || !isValidUrl(url)) return res.status(400).json({ error: "Valid ?url required" });

  try {
    const info = await ytdlp(url, {
      dumpSingleJson: true,
      noWarnings: true,
      noCheckCertificates: true,
      preferFreeFormats: true,
      addHeader: ["referer: https://www.youtube.com", "user-agent: Mozilla/5.0"],
    });

    // Map minimal info for frontend
    const payload = {
      id: info.id,
      title: info.title,
      uploader: info.uploader,
      duration: info.duration,
      thumbnail: (info.thumbnails && info.thumbnails.length) ? info.thumbnails.at(-1).url : info.thumbnail,
      formats: (info.formats || []).map(f => ({
        format_id: f.format_id,
        ext: f.ext,
        height: f.height,
        width: f.width,
        fps: f.fps,
        vcodec: f.vcodec,
        acodec: f.acodec,
        filesize: f.filesize || f.filesize_approx || null,
        format_note: f.format_note
      })).filter(f => !!f.ext)
    };

    res.json(payload);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Failed to fetch info" });
  }
});

// Stream download (tries 1080p best by default)
app.get("/download", async (req, res) => {
  const url = req.query.url;
  const height = parseInt(req.query.height || "1080", 10);
  const ext = req.query.ext || "mp4";

  if (!url || !isValidUrl(url)) return res.status(400).send("Valid ?url required");

  // Compose format selector: prefer requested height, fall back to best <= height
  const formatSelector = `bestvideo[height<=${height}][ext=${ext}]+bestaudio[ext=m4a]/best[height<=${height}][ext=${ext}]/best`;

  res.setHeader("Content-Type", "application/octet-stream");
  res.setHeader("Content-Disposition", `attachment; filename="video-${height}p.${ext}"`);

  try {
    const proc = ytdlp.exec(url, {
      format: formatSelector,
      remuxVideo: ext,        // ensure mp4 output container
      ffmpegLocation: ffmpegPath || undefined,
      maxFilesize: MAX_FILESIZE,
      output: "-",
      noWarnings: true,
      preferFreeFormats: true,
      noCheckCertificates: true,
      addHeader: ["referer: https://www.youtube.com", "user-agent: Mozilla/5.0"],
      // Pipe to stdout
      stdout: "pipe"
    });

    proc.stdout.pipe(res);

    proc.on("close", (code) => {
      if (code !== 0) {
        console.error("yt-dlp exited with code", code);
        if (!res.headersSent) res.status(500).end("Download failed");
      }
    });

    proc.stderr.on("data", (d) => {
      // Optional: log for debugging
      // console.error(String(d));
    });
  } catch (e) {
    console.error(e);
    if (!res.headersSent) res.status(500).end("Error starting download");
  }
});

app.listen(PORT, () => {
  console.log(`Server listening on :${PORT}`);
});
