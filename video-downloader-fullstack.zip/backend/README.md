
# Video Downloader Backend (Node + Express + yt-dlp)

> Educational demo. Downloading from YouTube/Instagram may violate their Terms of Service. Use responsibly.

## Features
- `/info?url=...` -> returns metadata and available formats
- `/download?url=...&height=1080&ext=mp4` -> streams merged MP4 using yt-dlp + ffmpeg-static
- CORS enabled for your frontend
- File size safety cap via `MAX_FILESIZE` (default 200M)

## Local Dev
```bash
npm install
cp .env.example .env
npm start
# open http://localhost:3000
```

## Deploy on Render
- Connect this folder as a Web Service
- Build: `npm install`
- Start: `npm start`
- Set `ALLOW_ORIGIN` to your Vercel domain when live
