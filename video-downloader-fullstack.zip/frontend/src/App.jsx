import React, { useState, useMemo } from "react";

const API_BASE = import.meta.env.VITE_API_BASE || "http://localhost:3000";

export default function App() {
  const [url, setUrl] = useState("");
  const [info, setInfo] = useState(null);
  const [loading, setLoading] = useState(false);
  const [height, setHeight] = useState(1080);
  const [error, setError] = useState("");

  const fetchInfo = async () => {
    setError("");
    setLoading(true);
    setInfo(null);
    try {
      const res = await fetch(`${API_BASE}/info?url=${encodeURIComponent(url)}`);
      if (!res.ok) throw new Error("Failed to fetch info");
      const data = await res.json();
      setInfo(data);
    } catch (e) {
      setError(e.message || "Error");
    } finally {
      setLoading(false);
    }
  };

  const bestHeights = useMemo(() => {
    if (!info?.formats) return [];
    const hs = Array.from(new Set(info.formats.map(f => f.height).filter(Boolean))).sort((a,b)=>a-b);
    return hs;
  }, [info]);

  const doDownload = () => {
    const dl = `${API_BASE}/download?url=${encodeURIComponent(url)}&height=${height}&ext=mp4`;
    window.location.href = dl;
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-white shadow-xl rounded-2xl p-6">
        <h1 className="text-2xl font-bold mb-2">Free Video Downloader</h1>
        <p className="text-sm text-gray-600 mb-6">Paste a YouTube/Shorts/Reels link and choose quality.</p>

        <div className="flex gap-2 mb-4">
          <input
            className="flex-1 border rounded-xl px-3 py-2 outline-none focus:ring-2 focus:ring-indigo-500"
            placeholder="https://www.youtube.com/watch?v=... or Instagram Reel URL"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
          />
          <button
            onClick={fetchInfo}
            className="px-4 py-2 rounded-xl bg-indigo-600 text-white disabled:opacity-50"
            disabled={!url || loading}
          >
            {loading ? "Loading..." : "Fetch"}
          </button>
        </div>

        {error && <div className="text-red-600 text-sm mb-3">{error}</div>}

        {info && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-start">
            <div className="md:col-span-1">
              {info.thumbnail && (
                <img src={info.thumbnail} alt="thumbnail" className="rounded-xl w-full" />
              )}
            </div>
            <div className="md:col-span-2">
              <h2 className="font-semibold">{info.title}</h2>
              <p className="text-sm text-gray-600 mb-3">{info.uploader}</p>

              <label className="text-sm font-medium">Quality</label>
              <select
                className="w-full border rounded-xl px-3 py-2 mb-3"
                value={height}
                onChange={(e) => setHeight(parseInt(e.target.value, 10))}
              >
                {[1080, 720, 480, 360, ...bestHeights].filter((v,i,arr)=>arr.indexOf(v)===i).sort((a,b)=>b-a).map(h => (
                  <option key={h} value={h}>{h}p</option>
                ))}
              </select>

              <button
                onClick={doDownload}
                className="w-full md:w-auto px-5 py-2 rounded-xl bg-green-600 text-white hover:bg-green-700"
              >
                Download MP4
              </button>
              <p className="text-xs text-gray-500 mt-2">
                For demo/educational use only. Respect platform Terms of Service.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
