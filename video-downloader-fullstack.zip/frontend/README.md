
# Video Downloader Frontend (Vite + React + Tailwind)

## Setup
```bash
npm install
cp .env.example .env
npm run dev
```

Set `VITE_API_BASE` to your backend URL on Render when deploying.
